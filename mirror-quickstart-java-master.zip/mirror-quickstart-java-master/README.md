Google Mirror API's Quickstart for Java
========================

The documentation for this quickstart is maintained on developers.google.com.
Please see here for more information:
https://developers.google.com/glass/quickstart/java
